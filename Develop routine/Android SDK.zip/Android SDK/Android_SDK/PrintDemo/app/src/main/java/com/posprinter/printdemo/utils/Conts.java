package com.posprinter.printdemo.utils;

public class Conts {
	public static final int ENABLE_BLUETOOTH=1;
	public static final int LABEL_PRINT=2;
	public static final int type_moban1=5;
	public static final int type_moban2=6;
	public static final int type_moban3=7;
	public static final int type_moban4=8;
	public static final int TAKE_PICTURE=100;
	public static final int LOAD_PICTURE_KITKAK=101;
	public static final int LOAD_PICTURE=102;
}
